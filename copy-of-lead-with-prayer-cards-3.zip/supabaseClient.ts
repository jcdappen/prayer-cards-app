import { createClient } from '@supabase/supabase-js'

// --- STEP 1: GET YOUR SUPABASE CREDENTIALS ---
// 1. Go to your Supabase project dashboard: https://supabase.com/dashboard
// 2. In the left sidebar, go to Project Settings (the gear icon).
// 3. Click on "API" in the settings list.
// 4. Under "Project API keys", you will find your "URL" and your "anon" "public" key.
// 5. Copy them and paste them into the `supabaseUrl` and `supabaseAnonKey` constants below.

const supabaseUrl: string = 'https://wrcnubaubjkxjxosmbp.supabase.co';
const supabaseAnonKey: string = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndyY251YmFtdWJqa3hqeG9zbWJwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM2MTUzNzQsImV4cCI6MjA2OTE5MTM3NH0.BxOBByRwUCI7vD1xgZGMkUARrpELP40OZP0U2BVGg_M';

// This check helps you know if you've configured Supabase correctly.
export const isSupabaseConfigured =
  supabaseUrl !== 'YOUR_SUPABASE_PROJECT_URL' &&
  supabaseAnonKey !== 'YOUR_SUPABASE_ANON_KEY';

// Initialize the client, but only if configured, to prevent app crashes.
// If not configured, we provide a dummy object so the app can still load and display the config message.
export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey)
  : {} as any;

if (!isSupabaseConfigured) {
    console.error("Supabase credentials are not set. Please update supabaseClient.ts with your project's URL and anon key from your Supabase dashboard.");
}
